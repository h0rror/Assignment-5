﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentGrades
{
    /**
    * <summary>
    * Class which contains student info
    * </summary>
    * @class newStudent
    */
    class newStudent
    {
        public string firstName { get; private set; }
        public string lastName { get; private set; }
        public string program { get; private set; }
        public string studentGrade { get; private set; }
        public string iD { get; private set; }
        /**
        * <summary>
        * Constructs a student with grades
        * </summary>
        * @constructor
        */
        private newStudent(string firstName, string lastName, string program, string grade, string id)
        {
            this.firstName = firstName;
            this.lastName = lastName;
            this.program = program;
            studentGrade = grade;
            iD = id;
        }
        public override string ToString()
        {
            return string.Format("{0}, {1}: {2} {3}, {4} ", lastName, firstName, program, studentGrade, iD);
        }
        public static newStudent Parse(string line)
        {
            string[] columns = line.Split(':');
            newStudent s = new newStudent(columns[0], columns[1], columns[2], columns[3], columns[4]);
            return s;
        }
    }
}