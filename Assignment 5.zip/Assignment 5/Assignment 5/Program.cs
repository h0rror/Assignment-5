﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace StudentGrades
{
    /**
    * Nikola Savin
    * 300635434 
    * <summary>
    * This class is the main program
    * </summary>
    * @class program
    */
    class Program
    {
        static void Main(string[] args)
        {
            string Selection;
            do
            {
                Console.Write("Make a Selection: ");
                Console.WriteLine("****************");
                Console.WriteLine("1. Display Grades");          //Prints out menu options
                Console.WriteLine("2. Quit");
                Console.WriteLine("****************");

                Selection = Console.ReadLine();         //Accepts user input

                switch (Selection)                   //User chooses either 1 or 2
                {
                    case "1":
                        Console.Write("Please enter the filename: ");
                        string fileString = Console.ReadLine();
                        OutputGrades(fileString);
                        break;
                    case "2":
                        Console.WriteLine("Quitting program...");
                        break;
                    default:
                        Console.WriteLine("Invalid option. Please select again.");
                        break;
                }
            }
            while (Selection != "2");
        }
        /**
        * <summary>
        * Method to read and display student grades from a chosen file.
        * </summary>
        * @static
        * @param {string} fileString
        * @method OutputGrades
        * @returns {void}
        */
        private static void OutputGrades(string fileString)
        {
            try
            {
                using (StreamReader reader = new StreamReader(fileString))        //Reads from chosen file name
                {
                    string fileData = reader.ReadLine();
                    while (fileData != null)
                    {
                        newStudent s = newStudent.Parse(fileData);
                        Console.WriteLine(s);
                        fileData = reader.ReadLine();
                    }
                }
            }
            catch (FileNotFoundException)
            {
                Console.WriteLine("File not found.");
            }
        }
    }
}